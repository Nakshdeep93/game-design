import SpriteKit
class GameScene: SKScene {
    override func didMove(to view: SKView) {
        let background = SKSpriteNode(imageNamed: "background1")
          addChild(background)
        background.anchorPoint = CGPoint.zero
        background.position = CGPoint.zero
        //background.zRotation = CGFloat.pi / 8
        //background.anchorPoint = CGPoint(x: 0.5, y: 0.5) // default
        //background.position = CGPoint(x: size.width/2, y: size.height/2)
        //background.position = CGPoint(x: size.width/2, y: size.height/2)
        backgroundColor = SKColor.black
        let mySize = background.size
        background.zPosition = -1
        let zombie = SKSpriteNode(imageNamed: "zombie1")
        zombie.position = CGPoint(x: 400, y: 400)
        addChild(zombie)
        print("Size: \(mySize)")
    }
}
